/* Clipper header file */
/* (C) 2000-2003 Kevin Cowtan */

#ifndef CLIPPER_MMDBOLD_H
#define CLIPPER_MMDBOLD_H

#include "clipper/mmdbold/container_mmdb.h"

#endif
