/* Clipper header file */
/* (C) 2000-2002 Kevin Cowtan */

#ifndef CLIPPER_CCTBX_H
#define CLIPPER_CCTBX_H

#include "clipper/cctbx/clipper_cctbx.h"

#endif
