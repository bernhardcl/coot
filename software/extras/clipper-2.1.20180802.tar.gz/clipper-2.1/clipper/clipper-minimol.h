/* Clipper header file */
/* (C) 2000-2003 Kevin Cowtan */

#ifndef CLIPPER_MINIMOL_H
#define CLIPPER_MINIMOL_H

#include "clipper/minimol/minimol_utils.h"
#include "clipper/minimol/minimol_io.h"
#include "clipper/minimol/container_minimol.h"

#endif
